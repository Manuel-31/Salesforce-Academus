# Salesforce Academy
```
npm install
npm run dev     # desenvolvimento
npm run build   # produção (inclui verificação TypeScript)
```
Dados guardados em localStorage. Conteúdos em `src/data/`. Verifique sempre a documentação oficial (Trailhead, Salesforce Help) pois as funcionalidades mudam a cada release.
Os certificados internos são de conclusão de formação, não certificações oficiais Salesforce.

## Publicar no GitHub (sem computador)
1. Crie um repositório e carregue todos os ficheiros (incluindo a pasta `.github`).
2. Settings → Pages → Source: **GitHub Actions**.
3. Faça push para `main`; o link fica em `https://<utilizador>.github.io/<repo>/`.
4. No telemóvel, abra o link e use "Adicionar ao ecrã principal" para instalar como app.
