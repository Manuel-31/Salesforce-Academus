# Salesforce Academy
```
npm install
npm run dev     # desenvolvimento
npm run build   # produção (inclui verificação TypeScript)
```
Dados guardados em localStorage. Conteúdos em `src/data/`. Verifique sempre a documentação oficial (Trailhead, Salesforce Help) pois as funcionalidades mudam a cada release.
Os certificados internos são de conclusão de formação, não certificações oficiais Salesforce.

## Android (Capacitor)
```
npm install
npm run build
npx cap add android
npx cap sync android
cd android && ./gradlew assembleDebug
```
APK: `android/app/build/outputs/apk/debug/app-debug.apk`.
Sem computador: use o workflow do GitHub Actions (descompacta este ZIP, gera o APK e publica-o em Releases).
