import {useState,useEffect,useRef} from 'react';
import {State,User,touch,streak} from './services/store';
import {MODS,LV,Mod} from './data/modules';
import {QS,Q} from './data/questions';
import {GL,LABS,CERTS} from './data/misc';
export type P={st:State;upd:(f:(s:State)=>State)=>void;user:User;go:(p:string)=>void};
const same=(a:number[],b:number[])=>a.length===b.length&&a.every(x=>b.includes(x));
const weak=(st:State)=>MODS.map(m=>{const[c,t]=st.stats[m.id]||[0,0];return{m,r:t?c/t:-1}}).filter(x=>x.r>=0&&x.r<0.7).sort((a,b)=>a.r-b.r).map(x=>x.m);

export function Dashboard({st,user,go}:P){
 const pct=Math.round(st.done.length/MODS.length*100);
 const avg=st.exams.length?Math.round(st.exams.reduce((a,e)=>a+e.score/e.total*100,0)/st.exams.length):0;
 const todo=MODS.filter(m=>!st.done.includes(m.id)),w=weak(st);
 const last=st.exams.slice(-8);
 return <div><h1>Olá, {user.name}!</h1>
 <div className="grid">{[['Progresso',pct+'%'],['Módulos concluídos',st.done.length+'/'+MODS.length],['Horas de estudo',(st.minutes/60).toFixed(1)],['Média nos exames',avg+'%'],['Pontos · Nível',st.points+' · '+(Math.floor(st.points/100)+1)],['Sequência',streak(st.days)+' dias']].map(([a,b])=><div className="card" key={a}><small>{a}</small><h2>{b}</h2></div>)}</div>
 <div className="card"><h3>Evolução nos exames</h3>{last.length?<svg viewBox="0 0 320 110" width="100%">{last.map((e,i)=>{const h=e.score/e.total*90;return <g key={i}><rect x={10+i*38} y={100-h} width="28" height={h} rx="3" fill="#1b6ef3"/><text x={24+i*38} y="108" fontSize="9" textAnchor="middle">{Math.round(e.score/e.total*100)}</text></g>})}</svg>:<p>Faça o primeiro exame para ver o gráfico.</p>}</div>
 <div className="card"><h3>Recomendações</h3>{w.length?<p>Rever: {w.map(m=>m.t).join(', ')}</p>:todo.length?<p>Continue com: <b>{todo[0].t}</b></p>:<p>Todos os módulos concluídos. Experimente um exame completo.</p>}<button onClick={()=>go(w.length||todo.length?'learn':'exam')}>Continuar</button></div>
 <div className="card"><h3>Histórico</h3>{st.exams.length?st.exams.slice(-5).reverse().map((e,i)=><p key={i}>{e.date} · {e.mode}: {e.score}/{e.total}</p>):<p>Sem atividade ainda.</p>}</div></div>}

function Quiz({m}:{m:Mod}){
 const qs=QS.filter(q=>q.mod===m.id);const[pick,setPick]=useState<Record<string,number>>({});
 return <div>{qs.map(q=><div key={q.id}><p><b>{q.q}</b></p>{q.o.map((o,i)=><button key={i} className={'opt '+(pick[q.id]!==undefined?(q.a.includes(i)?'ok':pick[q.id]===i?'bad':''):'')} onClick={()=>setPick({...pick,[q.id]:i})}>{o}</button>)}{pick[q.id]!==undefined&&<p className="hint">{q.e}</p>}</div>)}</div>}

export function Learn({st,upd}:P){
 const[m,setM]=useState<Mod|null>(null);
 if(!m)return <div><h1>Centro de aprendizagem</h1>{[1,2,3].map(l=><section key={l}><h2>{LV[l]}</h2><div className="grid">{MODS.filter(x=>x.lvl===l).map(x=><div className="card" key={x.id}><h3>{x.t}</h3><p>{x.sum}</p><button onClick={()=>setM(x)}>{st.done.includes(x.id)?'✓ Rever':'Abrir'}</button></div>)}</div></section>)}</div>;
 const done=st.done.includes(m.id);
 return <div className="card"><button className="ghost" onClick={()=>setM(null)}>← Voltar</button><h1>{m.t}</h1>
 <h3>Objetivos</h3><ul>{m.obj.map(o=><li key={o}>{o}</li>)}</ul>{m.txt.map(t=><p key={t}>{t}</p>)}
 <h3>Exemplo prático</h3><p>{m.ex}</p><h3>Exercício</h3><p>{m.exe}</p><h3>Questionário</h3><Quiz m={m}/>
 <h3>Resumo</h3><p>{m.sum}</p><p><a href={m.link[1]} target="_blank" rel="noreferrer">{m.link[0]} (material oficial)</a></p>
 <button disabled={done} onClick={()=>upd(s=>s.done.includes(m.id)?s:touch({...s,done:[...s.done,m.id]},50,20))}>{done?'✓ Concluído':'Marcar como concluído'}</button></div>}

type Mode={k:string;n:number;sec:number};
const MODES:Mode[]=[{k:'Simulado rápido',n:10,sec:600},{k:'Simulado intermédio',n:30,sec:1800},{k:'Exame completo',n:60,sec:5400},{k:'Modo prática',n:QS.length,sec:0}];
export function Exam({upd}:P){
 const[cfg,setCfg]=useState<Mode|null>(null);const[qs,setQs]=useState<Q[]>([]);const[i,setI]=useState(0);
 const[ans,setAns]=useState<number[][]>([]);const[fl,setFl]=useState<boolean[]>([]);const[left,setLeft]=useState(0);const[done,setDone]=useState(false);
 const t0=useRef(0);
 const start=(m:Mode)=>{const q=[...QS].sort(()=>Math.random()-.5).slice(0,Math.min(m.n,QS.length));
  setQs(q);setAns(q.map(()=>[]));setFl(q.map(()=>false));setI(0);setLeft(m.sec);setCfg(m);setDone(false);t0.current=Date.now()};
 const finish=()=>{if(done||!cfg)return;setDone(true);
  const ok=qs.map((q,k)=>same(q.a,ans[k]));const sc=ok.filter(Boolean).length;
  upd(s=>{const stats={...s.stats};qs.forEach((q,k)=>{const[c,t]=stats[q.mod]||[0,0];stats[q.mod]=[c+(ok[k]?1:0),t+1]});
   return touch({...s,stats,exams:[...s.exams,{date:new Date().toLocaleDateString('pt-PT'),mode:cfg.k,score:sc,total:qs.length,secs:Math.round((Date.now()-t0.current)/1000)}]},sc*2,Math.round((Date.now()-t0.current)/60000))})};
 useEffect(()=>{if(!cfg||done||!cfg.sec)return;const t=setInterval(()=>setLeft(l=>l-1),1000);return()=>clearInterval(t)},[cfg,done]);
 useEffect(()=>{if(cfg&&cfg.sec&&left<=0&&!done)finish()});
 if(!cfg)return <div><h1>Exames e simulados</h1><div className="grid">{MODES.map(m=><div className="card" key={m.k}><h3>{m.k}</h3><p>{Math.min(m.n,QS.length)} perguntas · {m.sec?m.sec/60+' min':'sem limite'}</p><button onClick={()=>start(m)}>Começar</button></div>)}</div><p className="hint">O banco atual tem {QS.length} perguntas; modos maiores usam todas as disponíveis.</p></div>;
 if(done){const ok=qs.map((q,k)=>same(q.a,ans[k]));const sc=ok.filter(Boolean).length;
  const bad=[...new Set(qs.filter((_,k)=>!ok[k]).map(q=>MODS.find(m=>m.id===q.mod)?.t))];
  return <div className="card"><h1>{sc}/{qs.length} · {Math.round(sc/qs.length*100)}%</h1><p>Certas: {sc} · Erradas: {qs.length-sc} · Tempo: {Math.round((Date.now()-t0.current)/1000)}s</p>
  <p><b>Estudar:</b> {bad.length?bad.join(', '):'Excelente! Sem pontos fracos.'}</p>
  {qs.map((q,k)=><div key={q.id} className={ok[k]?'res ok':'res bad'}><b>{k+1}. {q.q}</b><p>Correta: {q.a.map(x=>q.o[x]).join('; ')}</p><p className="hint">{q.e}</p></div>)}
  <button onClick={()=>setCfg(null)}>Novo exame</button></div>}
 const q=qs[i],cur=ans[i]||[],multi=q.a.length>1;
 const tog=(k:number)=>{const n=[...ans];n[i]=multi?(cur.includes(k)?cur.filter(x=>x!==k):[...cur,k]):[k];setAns(n)};
 return <div className="card"><div className="bar"><div style={{width:(ans.filter(a=>a.length).length/qs.length*100)+'%'}}/></div>
 <p>Pergunta {i+1}/{qs.length} {cfg.sec>0&&<b>· ⏱ {Math.floor(left/60)}:{String(left%60).padStart(2,'0')}</b>}{multi&&' · várias respostas'}</p>
 <h3>{q.q}</h3>{q.o.map((o,k)=><button key={k} className={'opt '+(cur.includes(k)?'sel':'')+(!cfg.sec&&cur.length?(q.a.includes(k)?' ok':cur.includes(k)?' bad':''):'')} onClick={()=>tog(k)}>{o}</button>)}
 {!cfg.sec&&cur.length>0&&<p className="hint">{q.e}</p>}
 <div className="row"><button className="ghost" disabled={!i} onClick={()=>setI(i-1)}>Anterior</button>
 <button className="ghost" onClick={()=>{const n=[...fl];n[i]=!n[i];setFl(n)}}>{fl[i]?'🚩 Desmarcar':'Marcar para revisão'}</button>
 {i<qs.length-1?<button onClick={()=>setI(i+1)}>Seguinte</button>:<button onClick={finish}>Terminar</button>}</div>
 <div className="dots">{qs.map((_,k)=><button key={k} className={'dot '+(k===i?'cur ':'')+(ans[k]?.length?'ans ':'')+(fl[k]?'flag':'')} onClick={()=>setI(k)}>{k+1}</button>)}</div></div>}

export function Glossary(){
 const[s,setS]=useState('');const r=GL.filter(g=>g.join(' ').toLowerCase().includes(s.toLowerCase()));
 return <div><h1>Glossário</h1><input placeholder="Pesquisar termo…" value={s} onChange={e=>setS(e.target.value)}/>
 {r.map(g=><div className="card" key={g[0]}><h3>{g[0]} <small>{g[1]}</small></h3><p>{g[2]}</p><p className="hint">Exemplo: {g[3]}</p></div>)}{!r.length&&<p>Nenhum termo encontrado. Tente outra palavra.</p>}</div>}

export function Lab({st,upd}:P){
 const[chk,setChk]=useState<Record<string,boolean>>({});
 return <div><h1>Salesforce Lab</h1>{LABS.map(l=>{const d=st.labs.includes(l.id);const all=l.steps.every((_,i)=>chk[l.id+i]);
 return <div className="card" key={l.id}><h3>{l.t}</h3><p><b>Cenário:</b> {l.cen}</p><p><b>Objetivo:</b> {l.obj}</p>
 {l.steps.map((s,i)=><label key={i} className="step"><input type="checkbox" checked={d||!!chk[l.id+i]} onChange={e=>setChk({...chk,[l.id+i]:e.target.checked})}/> {s}</label>)}
 <p><b>Resultado esperado:</b> {l.res}</p><p><b>Critérios:</b> {l.crit}</p>
 <button disabled={d||!all} onClick={()=>upd(s=>touch({...s,labs:[...s.labs,l.id]},40,25))}>{d?'✓ Concluído':'Concluir desafio'}</button></div>})}</div>}

export function Plan({st,upd}:P){
 const todo=MODS.filter(m=>!st.done.includes(m.id));const per=st.goal<=30?1:st.goal<=60?2:3;
 const days=Array.from({length:14},(_,i)=>{const d=new Date();d.setDate(d.getDate()+i);return{d:d.toLocaleDateString('pt-PT',{weekday:'short',day:'numeric',month:'short'}),m:todo.slice(Math.floor(i/per),Math.floor(i/per)+1)[0]}});
 return <div><h1>Meu plano de estudos</h1><div className="row">{[30,60,120].map(g=><button key={g} className={st.goal===g?'':'ghost'} onClick={()=>upd(s=>({...s,goal:g}))}>{g===30?'30 min':g===60?'1 hora':'2 horas'} por dia</button>)}</div>
 {days.map((x,i)=><div className="card" key={i}><b>{x.d}</b> — {x.m?'Estudar: '+x.m.t:'Fazer um exame simulado e rever pontos fracos'}</div>)}</div>}

export function Certs({st}:P){
 return <div><h1>Preparação para certificações</h1><p className="hint">Confirme sempre o exam guide oficial atualizado em trailhead.salesforce.com/credentials.</p>
 {CERTS.map(([n,d,ms])=>{const f=ms.filter(x=>st.done.includes(x)).length;return <div className="card" key={n}><h3>Salesforce Certified {n}</h3><p>{d}</p>
 <p><b>Plano:</b> {ms.map(x=>MODS.find(m=>m.id===x)?.t).join(' → ')}</p><div className="bar"><div style={{width:f/ms.length*100+'%'}}/></div><small>{f}/{ms.length} módulos concluídos</small></div>})}</div>}
