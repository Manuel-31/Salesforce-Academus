import {useState} from 'react';
import {User,State,cur,login,register,logout,loadState,saveState} from './services/store';
import {Dashboard,Learn,Exam,Glossary,Lab,Plan,Certs} from './pages';
const NAV:[string,string][]=[['home','Dashboard'],['learn','Aprender'],['exam','Exames'],['certs','Certificações'],['lab','Lab'],['plan','Plano'],['gloss','Glossário']];
function Auth({on}:{on:(u:User)=>void}){
 const[reg,setReg]=useState(false);const[n,setN]=useState('');const[e,setE]=useState('');const[p,setP]=useState('');const[err,setErr]=useState('');
 const go=()=>{const r=reg?register(n,e,p):login(e,p);typeof r==='string'?setErr(r):on(r)};
 return <div className="auth"><div className="card"><h1>Salesforce Academy</h1><p>Aprenda Salesforce do zero ao avançado.</p>
 {reg&&<input placeholder="Nome" value={n} onChange={x=>setN(x.target.value)}/>}
 <input placeholder="Email" value={e} onChange={x=>setE(x.target.value)}/>
 <input type="password" placeholder="Palavra-passe" value={p} onChange={x=>setP(x.target.value)}/>
 {err&&<p className="err">{err}</p>}
 <button onClick={go}>{reg?'Criar conta':'Iniciar sessão'}</button>
 <button className="ghost" onClick={()=>{setReg(!reg);setErr('')}}>{reg?'Já tenho conta':'Criar conta nova'}</button></div></div>}
export default function App(){
 const[user,setUser]=useState<User|null>(cur());
 const[st,setSt]=useState<State|null>(user?loadState(user.email):null);
 const[pg,setPg]=useState('home');
 if(!user||!st)return <Auth on={u=>{setUser(u);setSt(loadState(u.email))}}/>;
 const upd=(f:(s:State)=>State)=>setSt(p=>{const n=f(p as State);saveState(user.email,n);return n});
 const P={st,upd,user,go:setPg};
 return <div className="app"><nav>{<b className="logo">SF Academy</b>}
 {NAV.map(([k,l])=><button key={k} className={pg===k?'on':''} onClick={()=>setPg(k)}>{l}</button>)}
 <button onClick={()=>{logout();setUser(null);setSt(null)}}>Sair</button></nav>
 <main>{pg==='home'&&<Dashboard {...P}/>}{pg==='learn'&&<Learn {...P}/>}{pg==='exam'&&<Exam {...P}/>}
 {pg==='certs'&&<Certs {...P}/>}{pg==='lab'&&<Lab {...P}/>}{pg==='plan'&&<Plan {...P}/>}{pg==='gloss'&&<Glossary/>}</main></div>}
