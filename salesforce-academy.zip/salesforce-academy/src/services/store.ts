export type User={name:string;email:string;pw:string};
export type Exam={date:string;mode:string;score:number;total:number;secs:number};
export type State={done:string[];labs:string[];exams:Exam[];minutes:number;points:number;days:string[];goal:number;stats:Record<string,[number,number]>};
const K='sfa_';
function get<T>(k:string,d:T):T{try{const v=localStorage.getItem(K+k);return v?JSON.parse(v) as T:d}catch{return d}}
function set(k:string,v:unknown){localStorage.setItem(K+k,JSON.stringify(v))}
export const cur=():User|null=>{const e=get<string|null>('session',null);return get<User[]>('users',[]).find(u=>u.email===e)||null};
export function register(name:string,email:string,pw:string):User|string{
 const us=get<User[]>('users',[]);email=email.trim().toLowerCase();
 if(!name||!email||pw.length<6)return 'Preencha o nome, email e uma palavra-passe com 6+ caracteres.';
 if(us.some(u=>u.email===email))return 'Este email já está registado.';
 const u={name,email,pw};set('users',[...us,u]);set('session',email);return u}
export function login(email:string,pw:string):User|string{
 const u=get<User[]>('users',[]).find(x=>x.email===email.trim().toLowerCase()&&x.pw===pw);
 if(!u)return 'Email ou palavra-passe incorretos.';set('session',u.email);return u}
export const logout=()=>set('session',null);
const empty:State={done:[],labs:[],exams:[],minutes:0,points:0,days:[],goal:60,stats:{}};
export const loadState=(e:string):State=>({...empty,...get<Partial<State>>('state_'+e,{})});
export const saveState=(e:string,s:State)=>set('state_'+e,s);
export const touch=(s:State,pts:number,mins=0):State=>{const d=new Date().toISOString().slice(0,10);
 return {...s,points:s.points+pts,minutes:s.minutes+mins,days:s.days.includes(d)?s.days:[...s.days,d]}};
export const streak=(days:string[]):number=>{let n=0;const d=new Date();
 while(days.includes(d.toISOString().slice(0,10))){n++;d.setDate(d.getDate()-1)}return n};
