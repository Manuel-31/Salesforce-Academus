export const GL:[string,string,string,string][]=[
['CRM','Gestão de Relacionamento com Clientes','Estratégia e sistema para gerir interações com clientes.','Registar todas as chamadas de um cliente.'],
['Lead','Potencial cliente','Contacto ainda não qualificado.','Alguém que preencheu um formulário no site.'],
['Account','Conta / Empresa','Organização com quem se faz negócio.','Tech Lda.'],
['Contact','Contacto','Pessoa associada a uma Account.','Maria Silva, diretora de compras.'],
['Opportunity','Oportunidade','Venda potencial com valor e fase.','Licenças anuais, 20.000€.'],
['Object','Objeto','Tabela de dados no Salesforce (standard ou custom).','Account, Invoice__c.'],
['Record','Registo','Uma linha de dados num objeto.','A Account "Tech Lda".'],
['Flow','Fluxo','Ferramenta declarativa de automação.','Criar tarefa quando a Opportunity fecha.'],
['Apex','Apex','Linguagem de programação server-side do Salesforce.','Um trigger que valida dados.'],
['SOQL','Salesforce Object Query Language','Linguagem de consulta a registos.','SELECT Name FROM Account'],
['Dashboard','Painel','Conjunto visual de componentes baseados em relatórios.','Painel de vendas mensais.'],
['Report','Relatório','Lista ou resumo de registos filtrados.','Opportunities por fase.'],
['Profile','Perfil','Define permissões base de um utilizador.','Standard User.'],
['Permission Set','Conjunto de permissões','Acrescenta permissões a utilizadores.','Acesso a exportar reports.'],
['Role','Função (hierarquia)','Posição na hierarquia que determina visibilidade de registos.','Gestor de Vendas.'],
['Sharing Rules','Regras de partilha','Concedem acesso adicional a registos.','Partilhar Accounts com o grupo Finanças.'],
['Lightning Experience','Experiência Lightning','Interface moderna do Salesforce.','Acessível pelo App Launcher.']];
export const LABS=[
{id:'l1',t:'Converter um Lead',cen:'A equipa comercial qualificou um Lead de um evento.',obj:'Converter o Lead em Account, Contact e Opportunity.',steps:['Abra o separador Leads e crie um Lead com Company e Last Name','Abra o Lead e clique em Convert','Escolha criar uma nova Account e Opportunity','Clique em Convert e abra os registos criados'],res:'Existem Account, Contact e Opportunity ligados.',crit:'Registos criados e corretamente associados.'},
{id:'l2',t:'Relatório e Dashboard de vendas',cen:'O diretor quer ver as vendas por fase.',obj:'Criar um relatório Summary e um dashboard.',steps:['Reports > New Report > Opportunities','Agrupe por Stage','Guarde o relatório','Crie um Dashboard e adicione um componente com este relatório'],res:'Dashboard com gráfico por Stage.',crit:'Agrupamento correto e dashboard guardado.'},
{id:'l3',t:'Flow de onboarding',cen:'Ao fechar um negócio deve ser criada uma tarefa.',obj:'Automatizar com Record-Triggered Flow.',steps:['Setup > Flows > New Flow > Record-Triggered','Objeto Opportunity, quando criado ou atualizado','Condição: Stage = Closed Won','Adicione Create Records (Task) e ative o Flow'],res:'Task criada automaticamente ao fechar.',crit:'Flow ativo e Task gerada.'}];
export const CERTS=[
['Administrator','Valida competências de administração: configuração, segurança, dados, automação e relatórios.',['a1','a2','i2','d1']],
['Platform App Builder','Construção de aplicações declarativas: modelo de dados, UI e automação.',['i2','a2','d1']],
['Platform Developer I','Programação Apex, SOQL, LWC e testes.',['d2','d3','d1']],
['Sales Representative','Processos de vendas e uso do Sales Cloud.',['i1','i2']],
['Business Analyst','Levantamento de requisitos e tradução em soluções Salesforce.',['i1','a2','d1']]] as [string,string,string[]][];
